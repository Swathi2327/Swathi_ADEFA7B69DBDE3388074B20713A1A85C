def deposit(self);
amount =float(input ("Enter amount to be deposited:"))
self.balance+=amount
print("\n amount deposited :".amount)